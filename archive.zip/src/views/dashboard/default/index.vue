<template>
    <div class="dashboard-editor-container">
        dashboard
    </div>
</template>
